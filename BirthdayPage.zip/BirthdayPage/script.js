var a=prompt("Enter UserName");
 var b=prompt("Enter password");
  	if(a== "Eman Sabir" && b=="27-06-1996")
  	{
  	    window.location.href="start.html";
  	}
  	else
  	{
  		alert("invalid details");
  		window.location.href="index.html";
  	}
  	